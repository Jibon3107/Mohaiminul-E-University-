<?php
session_start();
echo "welcome user home";
$a=$_SESSION['email'];
echo "<h1>welcome $a</h1>";
?>